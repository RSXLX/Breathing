/** Zero-dependency bundle for this project's explicit named-import ES modules.
 * This is NOT a general JavaScript bundler. The normal app uses native modules.
 */
import { readFile, mkdir, writeFile, cp } from 'node:fs/promises';
import { resolve, dirname, extname } from 'node:path';
const root=resolve('public'),modules=new Map();
async function collect(path){
  path=resolve(path);if(modules.has(path))return;
  const source=await readFile(path,'utf8'),imports=[...source.matchAll(/^import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"];?\s*$/gm)];
  for(const match of imports)await collect(resolve(dirname(path),match[2]));
  modules.set(path,{source,imports});
}
await collect(resolve(root,'js/app.js'));
const keys=new Map([...modules.keys()].map((path,i)=>[path,`m${i}`]));
let script='const __modules = {};\n';
for(const [path,{source,imports}] of modules){
  const exports=[...source.matchAll(/^export\s+(?:async\s+)?(?:function|class|const|let)\s+([A-Za-z_$][\w$]*)/gm)].map(m=>m[1]);
  let body=source;
  for(const match of imports){const names=match[1].replace(/\s+as\s+/g,':');body=body.replace(match[0],`const {${names}}=__modules['${keys.get(resolve(dirname(path),match[2]))}'];\n`);}
  body=body.replace(/^export\s+/gm,'');
  script+=`\n__modules['${keys.get(path)}']=(()=>{\n${body}\nreturn {${exports.join(',')}};\n})();\n`;
}
let css=await readFile(resolve(root,'css/app.css'),'utf8'),html=await readFile(resolve(root,'index.html'),'utf8');
// Inline only first-party assets for a truly portable local preview. No fonts are bundled.
const paths=new Set([...script.matchAll(/['"](\/assets\/[^'"]+)['"]/g),...css.matchAll(/['"](\/assets\/[^'"]+)['"]/g)].map(m=>m[1]));
for(const path of paths){const data=await readFile(resolve(root,'.'+path)),mime={'.svg':'image/svg+xml','.png':'image/png','.glb':'model/gltf-binary'}[extname(path)];const uri=`data:${mime};base64,${data.toString('base64')}`;script=script.split(`'${path}'`).join(`'${uri}'`).split(`"${path}"`).join(`"${uri}"`);css=css.split(path).join(uri);}
html=html.replace('<link rel="stylesheet" href="/css/app.css">',`<style>${css}</style>`).replace('<script type="module" src="/js/app.js"></script>',()=>`<script type="module">${script.replace(/<\/script/gi,'<\\/script')}</script>`);
await mkdir('dist',{recursive:true});await cp('public','dist/web',{recursive:true});await writeFile('dist/breathe-city-preview.html',html);
console.log(`Build passed. Portable preview: dist/breathe-city-preview.html (${Math.round(Buffer.byteLength(html)/1024)} KB).`);
