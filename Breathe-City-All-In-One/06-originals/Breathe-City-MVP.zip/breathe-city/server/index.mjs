import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { loadConfig } from './config.mjs';
import { JobStore } from './store.mjs';
import { createProviders } from './providers.mjs';
import { JobWorker } from './worker.mjs';
import { createHttpApp } from './http.mjs';
if(existsSync('.env')) process.loadEnvFile('.env');
const config=loadConfig();
const store=new JobStore(config.dataDir), providers=createProviders(config);
const worker=new JobWorker(store,providers);
const app=createHttpApp({config,store,providers,publicDir:fileURLToPath(new URL('../public/',import.meta.url))});
app.listen(config.port,config.host,()=>{
  worker.start();
  console.log(`\n  BREATHE CITY / 城市呼吸相机\n  Open: ${config.origin}\n  Local rendering works without API keys.\n  Press Ctrl+C to stop.\n`);
});
app.on('error',err=>{console.error(`Server failed (${err.code || 'unknown'}). Check the port and HOST.`);process.exitCode=1;void worker.stop().then(()=>store.close());});
let closing=false;
async function close(){if(closing)return;closing=true;app.close();await worker.stop();store.close();process.exit(0);}
process.on('SIGINT',close);process.on('SIGTERM',close);
